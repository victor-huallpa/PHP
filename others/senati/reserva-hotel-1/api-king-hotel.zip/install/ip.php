<?php
$localIP = $_SERVER['SERVER_ADDR'];
echo "La dirección IP estática local es: " . $localIP;
